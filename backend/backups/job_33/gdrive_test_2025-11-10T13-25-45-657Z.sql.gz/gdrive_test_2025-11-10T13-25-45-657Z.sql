--
-- Database creation with UTF8 encoding (safe for all platforms)
--

CREATE DATABASE gdrive_test WITH ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C' TEMPLATE = template0;

ALTER DATABASE gdrive_test OWNER TO postgres;

\connect gdrive_test

--
-- PostgreSQL database dump
--

\restrict ucjI58fJ7tH5UQvcDPBdcUhJeZphm4SVtQgw5fslp3TTK0lpRinbydMULyVbTHq

-- Dumped from database version 14.19
-- Dumped by pg_dump version 14.19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict ucjI58fJ7tH5UQvcDPBdcUhJeZphm4SVtQgw5fslp3TTK0lpRinbydMULyVbTHq

