--
-- Database creation with UTF8 encoding (safe for all platforms)
--

CREATE DATABASE incdb WITH ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C' TEMPLATE = template0;

ALTER DATABASE incdb OWNER TO postgres;

\connect incdb

--
-- PostgreSQL database dump
--

\restrict NVubIApmhbFHofMg6UE5BdaXXpi2wu5uAMVsNEH0AMu0hsQh0gTfSSe81AKKgdI

-- Dumped from database version 14.19
-- Dumped by pg_dump version 14.19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: calisanlar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calisanlar (
    id integer NOT NULL,
    ad character varying(50) NOT NULL,
    soyad character varying(50) NOT NULL,
    departman character varying(30),
    maas numeric(10,2),
    ise_giris_tarihi date,
    email character varying(100)
);


ALTER TABLE public.calisanlar OWNER TO postgres;

--
-- Name: calisanlar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.calisanlar_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.calisanlar_id_seq OWNER TO postgres;

--
-- Name: calisanlar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.calisanlar_id_seq OWNED BY public.calisanlar.id;


--
-- Name: calisanlar id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calisanlar ALTER COLUMN id SET DEFAULT nextval('public.calisanlar_id_seq'::regclass);


--
-- Data for Name: calisanlar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.calisanlar (id, ad, soyad, departman, maas, ise_giris_tarihi, email) FROM stdin;
1	Ahmet	Yılmaz	Yazılım	15000.00	2022-03-15	ahmet.yilmaz@sirket.com
2	Ayşe	Demir	İnsan Kaynakları	12000.00	2021-07-20	ayse.demir@sirket.com
3	Mehmet	Kaya	Yazılım	18000.00	2020-01-10	mehmet.kaya@sirket.com
4	Zeynep	Şahin	Pazarlama	14000.00	2023-05-08	zeynep.sahin@sirket.com
\.


--
-- Name: calisanlar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.calisanlar_id_seq', 4, true);


--
-- Name: calisanlar calisanlar_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calisanlar
    ADD CONSTRAINT calisanlar_email_key UNIQUE (email);


--
-- Name: calisanlar calisanlar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calisanlar
    ADD CONSTRAINT calisanlar_pkey PRIMARY KEY (id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict NVubIApmhbFHofMg6UE5BdaXXpi2wu5uAMVsNEH0AMu0hsQh0gTfSSe81AKKgdI

