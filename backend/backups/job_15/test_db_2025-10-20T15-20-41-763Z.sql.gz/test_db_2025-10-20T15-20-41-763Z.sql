--
-- Database creation with UTF8 encoding (safe for all platforms)
--

CREATE DATABASE test_db WITH ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C' TEMPLATE = template0;

ALTER DATABASE test_db OWNER TO postgres;

\connect test_db

--
-- PostgreSQL database dump
--

\restrict qiGoXNZ9ERBmfskKK9nbZc0N5rn8JtHWNpHdaqiq23ZGfUeoM78nLKT1JyC8hCE

-- Dumped from database version 14.19
-- Dumped by pg_dump version 14.19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: urunler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.urunler (
    urun_id integer NOT NULL,
    urun_adi character varying(255) NOT NULL,
    aciklama text,
    fiyat numeric(10,2) NOT NULL,
    stok_adeti integer DEFAULT 0,
    eklenme_tarihi timestamp with time zone DEFAULT now()
);


ALTER TABLE public.urunler OWNER TO postgres;

--
-- Name: urunler_urun_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.urunler_urun_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.urunler_urun_id_seq OWNER TO postgres;

--
-- Name: urunler_urun_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.urunler_urun_id_seq OWNED BY public.urunler.urun_id;


--
-- Name: urunler urun_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.urunler ALTER COLUMN urun_id SET DEFAULT nextval('public.urunler_urun_id_seq'::regclass);


--
-- Data for Name: urunler; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.urunler (urun_id, urun_adi, aciklama, fiyat, stok_adeti, eklenme_tarihi) FROM stdin;
1	Laptop Bilgisayar	Yüksek performanslı, 16GB RAM, 512GB SSD dizüstü bilgisayar	25000.99	15	2025-10-16 17:40:06.851784+03
2	Akıllı Telefon	128GB depolama, 6.5 inç OLED ekranlı son model telefon	18500.50	40	2025-10-16 17:40:06.851784+03
3	Mekanik Klavye	Oyuncular için RGB aydınlatmalı, kırmızı switchli klavye	1200.00	75	2025-10-16 17:40:06.851784+03
4	Kablosuz Mouse	Ergonomik tasarımlı, 8 tuşlu kablosuz oyuncu mouse	450.75	120	2025-10-16 17:40:06.851784+03
5	4K Monitör	27 inç, IPS panel, 144Hz yenileme hızına sahip 4K monitör	9800.00	22	2025-10-16 17:40:06.851784+03
\.


--
-- Name: urunler_urun_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.urunler_urun_id_seq', 5, true);


--
-- Name: urunler urunler_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.urunler
    ADD CONSTRAINT urunler_pkey PRIMARY KEY (urun_id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict qiGoXNZ9ERBmfskKK9nbZc0N5rn8JtHWNpHdaqiq23ZGfUeoM78nLKT1JyC8hCE

