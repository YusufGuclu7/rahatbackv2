--
-- PostgreSQL database dump
--

\restrict cSXh6fVsIS8fMh66S6bL3RZE9FefqKtRTxvEsLieDuztjZAIguSZRvuYyfbqg10

-- Dumped from database version 14.19
-- Dumped by pg_dump version 14.19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: BackupStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."BackupStatus" AS ENUM (
    'running',
    'success',
    'failed',
    'cancelled'
);


ALTER TYPE public."BackupStatus" OWNER TO postgres;

--
-- Name: DatabaseType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DatabaseType" AS ENUM (
    'postgresql',
    'mysql',
    'mongodb',
    'mssql',
    'mariadb',
    'sqlite'
);


ALTER TYPE public."DatabaseType" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'user',
    'admin'
);


ALTER TYPE public."Role" OWNER TO postgres;

--
-- Name: ScheduleType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ScheduleType" AS ENUM (
    'manual',
    'hourly',
    'daily',
    'weekly',
    'monthly',
    'custom'
);


ALTER TYPE public."ScheduleType" OWNER TO postgres;

--
-- Name: StorageType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."StorageType" AS ENUM (
    'local',
    's3',
    'ftp',
    'azure',
    'google_drive'
);


ALTER TYPE public."StorageType" OWNER TO postgres;

--
-- Name: TokenType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TokenType" AS ENUM (
    'access',
    'refresh',
    'resetPassword',
    'verifyEmail'
);


ALTER TYPE public."TokenType" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: BackupHistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BackupHistory" (
    id integer NOT NULL,
    "backupJobId" integer,
    "databaseId" integer NOT NULL,
    status public."BackupStatus" NOT NULL,
    "fileName" text NOT NULL,
    "fileSize" bigint,
    "filePath" text NOT NULL,
    duration integer,
    "errorMessage" text,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public."BackupHistory" OWNER TO postgres;

--
-- Name: BackupHistory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."BackupHistory_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BackupHistory_id_seq" OWNER TO postgres;

--
-- Name: BackupHistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."BackupHistory_id_seq" OWNED BY public."BackupHistory".id;


--
-- Name: BackupJob; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BackupJob" (
    id integer NOT NULL,
    "databaseId" integer NOT NULL,
    name text NOT NULL,
    "scheduleType" public."ScheduleType" NOT NULL,
    "cronExpression" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "storageType" public."StorageType" NOT NULL,
    "storagePath" text NOT NULL,
    "retentionDays" integer DEFAULT 30 NOT NULL,
    compression boolean DEFAULT true NOT NULL,
    "lastRunAt" timestamp(3) without time zone,
    "nextRunAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "cloudStorageId" integer
);


ALTER TABLE public."BackupJob" OWNER TO postgres;

--
-- Name: BackupJob_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."BackupJob_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BackupJob_id_seq" OWNER TO postgres;

--
-- Name: BackupJob_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."BackupJob_id_seq" OWNED BY public."BackupJob".id;


--
-- Name: CloudStorage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CloudStorage" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    name text NOT NULL,
    "storageType" public."StorageType" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "s3Region" text,
    "s3Bucket" text,
    "s3AccessKeyId" text,
    "s3SecretAccessKey" text,
    "s3Endpoint" text,
    "gdRefreshToken" text,
    "gdFolderId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."CloudStorage" OWNER TO postgres;

--
-- Name: CloudStorage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CloudStorage_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."CloudStorage_id_seq" OWNER TO postgres;

--
-- Name: CloudStorage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CloudStorage_id_seq" OWNED BY public."CloudStorage".id;


--
-- Name: Database; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Database" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    name text NOT NULL,
    type public."DatabaseType" NOT NULL,
    host text NOT NULL,
    port integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    database text NOT NULL,
    "connectionString" text,
    "sslEnabled" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastTestedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Database" OWNER TO postgres;

--
-- Name: Database_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Database_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Database_id_seq" OWNER TO postgres;

--
-- Name: Database_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Database_id_seq" OWNED BY public."Database".id;


--
-- Name: NotificationSettings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."NotificationSettings" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "emailEnabled" boolean DEFAULT true NOT NULL,
    "notifyOnSuccess" boolean DEFAULT true NOT NULL,
    "notifyOnFailure" boolean DEFAULT true NOT NULL,
    "dailySummaryEnabled" boolean DEFAULT false NOT NULL,
    "dailySummaryTime" text DEFAULT '09:00'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "recipientEmail" text
);


ALTER TABLE public."NotificationSettings" OWNER TO postgres;

--
-- Name: NotificationSettings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."NotificationSettings_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."NotificationSettings_id_seq" OWNER TO postgres;

--
-- Name: NotificationSettings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."NotificationSettings_id_seq" OWNED BY public."NotificationSettings".id;


--
-- Name: Token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Token" (
    id integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    token text NOT NULL,
    type public."TokenType" NOT NULL,
    "userId" integer NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    blacklisted boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Token" OWNER TO postgres;

--
-- Name: Token_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Token_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Token_id_seq" OWNER TO postgres;

--
-- Name: Token_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Token_id_seq" OWNED BY public."Token".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    status boolean DEFAULT true NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    role public."Role" DEFAULT 'user'::public."Role" NOT NULL,
    "isEmailVerified" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."User_id_seq" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: BackupHistory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BackupHistory" ALTER COLUMN id SET DEFAULT nextval('public."BackupHistory_id_seq"'::regclass);


--
-- Name: BackupJob id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BackupJob" ALTER COLUMN id SET DEFAULT nextval('public."BackupJob_id_seq"'::regclass);


--
-- Name: CloudStorage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CloudStorage" ALTER COLUMN id SET DEFAULT nextval('public."CloudStorage_id_seq"'::regclass);


--
-- Name: Database id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Database" ALTER COLUMN id SET DEFAULT nextval('public."Database_id_seq"'::regclass);


--
-- Name: NotificationSettings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NotificationSettings" ALTER COLUMN id SET DEFAULT nextval('public."NotificationSettings_id_seq"'::regclass);


--
-- Name: Token id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Token" ALTER COLUMN id SET DEFAULT nextval('public."Token_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Data for Name: BackupHistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BackupHistory" (id, "backupJobId", "databaseId", status, "fileName", "fileSize", "filePath", duration, "errorMessage", "startedAt", "completedAt") FROM stdin;
22	2	1	running		\N		\N	\N	2025-10-15 08:08:39.972	\N
8	3	2	success	yenitest_2025-10-10T13-57-46-877Z.sql.gz	378	C:\\Users\\USER\\rahatback\\backend\\backups\\job_3\\yenitest_2025-10-10T13-57-46-877Z.sql.gz	0	\N	2025-10-10 13:57:46.867	2025-10-10 13:57:47.178
14	\N	1	success	rahat_fatura_db_2025-10-14T14-29-38-694Z.sql.gz	10153	1x8sdfWKs1fFlHjh8w5baaY2AcTKtp2Ao	0	\N	2025-10-14 14:29:38.69	2025-10-14 14:29:40.985
19	\N	1	success	rahat_fatura_db_2025-10-15T07-57-31-625Z.sql.gz	10318	C:\\Users\\USER\\rahatback\\backend\\backups\\job_4\\rahat_fatura_db_2025-10-15T07-57-31-625Z.sql.gz	0	\N	2025-10-15 07:57:31.615	2025-10-15 07:57:31.943
17	\N	1	success	rahat_fatura_db_2025-10-15T07-49-54-980Z.sql.gz	10215	C:\\Users\\USER\\rahatback\\backend\\backups\\job_4\\rahat_fatura_db_2025-10-15T07-49-54-980Z.sql.gz	0	\N	2025-10-15 07:49:54.961	2025-10-15 07:49:55.305
20	6	1	success	rahat_fatura_db_2025-10-15T07-59-42-065Z.sql.gz	10354	1IuZS238gESb2v6qPVkBFS694hoCXzk9A	0	\N	2025-10-15 07:59:42.051	2025-10-15 07:59:43.969
21	6	1	success	rahat_fatura_db_2025-10-15T08-05-20-958Z.sql.gz	10411	1zEg_tqC_2bnY7i257KiNSUfWqzR9jj3B	0	\N	2025-10-15 08:05:20.947	2025-10-15 08:05:22.831
\.


--
-- Data for Name: BackupJob; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BackupJob" (id, "databaseId", name, "scheduleType", "cronExpression", "isActive", "storageType", "storagePath", "retentionDays", compression, "lastRunAt", "nextRunAt", "createdAt", "updatedAt", "cloudStorageId") FROM stdin;
3	2	yusuftest - Backup	daily		t	local	/backups/yusuftest	30	t	2025-10-10 13:57:47.186	2025-10-15 23:00:00	2025-10-10 13:56:15.972	2025-10-15 08:04:35.949	\N
2	1	Test PostgreSQL DB - Backup	daily		t	local	/backups/test_postgresql_db	30	t	2025-10-10 12:59:04.026	2025-10-15 23:00:00	2025-10-08 11:41:55.504	2025-10-15 08:04:35.96	\N
6	1	Google drive backup	daily		t	google_drive	/backups/test_postgresql_db	30	t	2025-10-15 08:05:22.846	2025-10-15 23:00:00	2025-10-15 07:59:33.026	2025-10-15 08:05:22.842	2
\.


--
-- Data for Name: CloudStorage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CloudStorage" (id, "userId", name, "storageType", "isActive", "isDefault", "s3Region", "s3Bucket", "s3AccessKeyId", "s3SecretAccessKey", "s3Endpoint", "gdRefreshToken", "gdFolderId", "createdAt", "updatedAt") FROM stdin;
2	3	google drive backup	google_drive	t	f	eu-central-1					1//09EzCUFkPlS1fCgYIARAAGAkSNwF-L9IraIipw1PFW7aSAFVzdFrtegGlnYPUR7fVU6vXjmCr0Vh_4wHcNt9eijYFKx-JkVEgIh0		2025-10-14 14:08:09.636	2025-10-14 14:08:09.636
\.


--
-- Data for Name: Database; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Database" (id, "userId", name, type, host, port, username, password, database, "connectionString", "sslEnabled", "isActive", "lastTestedAt", "createdAt", "updatedAt") FROM stdin;
2	4	yusuftest	postgresql	localhost	5432	postgres	f4617ac7c4759c10388730ca0f953ccb:e844e5ec7d9109f05c5d3ad76b4c8c0f	yenitest		f	t	\N	2025-10-10 13:54:35.98	2025-10-10 13:54:35.98
1	3	Test PostgreSQL DB	postgresql	localhost	5432	postgres	84535c7bac2f598023731f3ee52de04e:738fcd67ca4566e3a7829b836141e6fa	rahat_fatura_db		f	t	2025-10-14 09:34:57.089	2025-10-08 09:33:54.496	2025-10-14 09:34:57.09
\.


--
-- Data for Name: NotificationSettings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."NotificationSettings" (id, "userId", "emailEnabled", "notifyOnSuccess", "notifyOnFailure", "dailySummaryEnabled", "dailySummaryTime", "createdAt", "updatedAt", "isActive", "recipientEmail") FROM stdin;
2	4	t	t	t	f	09:00	2025-10-10 22:22:33.354	2025-10-10 22:22:33.354	t	yusufguclu99@hotmail.com
1	3	t	f	t	t	09:00	2025-10-09 10:53:07.374	2025-10-09 10:53:07.374	t	yusufguclu99@hotmail.com
\.


--
-- Data for Name: Token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Token" (id, "createdAt", "updatedAt", token, type, "userId", "expiresAt", blacklisted) FROM stdin;
25	2025-10-08 20:28:59.715	2025-10-08 20:28:59.715	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTU1MzM5LCJleHAiOjE3NjI1NDczMzksInR5cGUiOiJyZWZyZXNoIn0.UDSdqMCwqJX5TYkMygn4z0efW2k6bg5JXsz9JfjjxPI	refresh	3	2025-11-07 20:28:59.711	f
26	2025-10-09 07:13:33.178	2025-10-09 07:13:33.178	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTk0MDEzLCJleHAiOjE3NjI1ODYwMTMsInR5cGUiOiJyZWZyZXNoIn0.uJIKnVqpf_6OkxuGKyxPte3DZIaEoEypDdQd1sFB5J8	refresh	3	2025-11-08 07:13:33.173	f
27	2025-10-09 08:09:57.329	2025-10-09 08:09:57.329	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTk3Mzk3LCJleHAiOjE3NjI1ODkzOTcsInR5cGUiOiJyZWZyZXNoIn0.QzPpTcqlsAYlqNTVvtyrpsNZ_bLD5IPXn7tCdlpC3Ek	refresh	3	2025-11-08 08:09:57.325	f
28	2025-10-09 08:20:53.009	2025-10-09 08:20:53.009	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTk4MDUzLCJleHAiOjE3NjI1OTAwNTMsInR5cGUiOiJyZWZyZXNoIn0.SqQ9loEVY9DzGqHsgGHXyr_oOPFVtAc0MNxMLBntsk8	refresh	3	2025-11-08 08:20:53.004	f
1	2025-10-08 08:18:38.599	2025-10-08 08:18:38.599	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjIsImlhdCI6MTc1OTkxMTUxOCwiZXhwIjoxNzYyNTAzNTE4LCJ0eXBlIjoicmVmcmVzaCJ9.RjD7rsUXSPfJxd8j_JWa6dp0wQJxFm4fQ_T9SPte9ns	refresh	2	2025-11-07 08:18:38.594	f
2	2025-10-08 08:18:47.279	2025-10-08 08:18:47.279	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjIsImlhdCI6MTc1OTkxMTUyNywiZXhwIjoxNzYyNTAzNTI3LCJ0eXBlIjoicmVmcmVzaCJ9.9sJZFXS3pcBro823R-g_k9PX0-VzBRoQXLTHi8hNxTY	refresh	2	2025-11-07 08:18:47.278	f
3	2025-10-08 08:22:23.465	2025-10-08 08:22:23.465	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjIsImlhdCI6MTc1OTkxMTc0MywiZXhwIjoxNzYyNTAzNzQzLCJ0eXBlIjoicmVmcmVzaCJ9.i_E8sc9uKC0O2Aa2kZQRUFxLb7Hsi5TnSOs4ny7YaKM	refresh	2	2025-11-07 08:22:23.463	f
4	2025-10-08 08:22:24.714	2025-10-08 08:22:24.714	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjIsImlhdCI6MTc1OTkxMTc0NCwiZXhwIjoxNzYyNTAzNzQ0LCJ0eXBlIjoicmVmcmVzaCJ9.44h4GVwiUyf-ycJnUNLHy_C57fqX5whovXH4ltYpDJA	refresh	2	2025-11-07 08:22:24.712	f
5	2025-10-08 08:28:39.223	2025-10-08 08:28:39.223	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsImlhdCI6MTc1OTkxMjExOSwiZXhwIjoxNzYyNTA0MTE5LCJ0eXBlIjoicmVmcmVzaCJ9.Y_UqTPvfutrHIhFzjvFSU5aNRYT-xh3x3etw2oatPiY	refresh	3	2025-11-07 08:28:39.221	f
6	2025-10-08 08:28:47.769	2025-10-08 08:28:47.769	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsImlhdCI6MTc1OTkxMjEyNywiZXhwIjoxNzYyNTA0MTI3LCJ0eXBlIjoicmVmcmVzaCJ9.lrvW2qv9-Ib2lPdx3mhOwLMY4BNi2TEKfmuyeN95Kyg	refresh	3	2025-11-07 08:28:47.769	f
7	2025-10-08 08:33:23.579	2025-10-08 08:33:23.579	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsImlhdCI6MTc1OTkxMjQwMywiZXhwIjoxNzYyNTA0NDAzLCJ0eXBlIjoicmVmcmVzaCJ9.S_yInt6cIAgq5QRsrONPnTOQZHBWpChrkahYJZWPhg4	refresh	3	2025-11-07 08:33:23.575	f
8	2025-10-08 08:33:25.272	2025-10-08 08:33:25.272	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsImlhdCI6MTc1OTkxMjQwNSwiZXhwIjoxNzYyNTA0NDA1LCJ0eXBlIjoicmVmcmVzaCJ9.O3xMldlkV1LFfYeqk--ZKmx0K4-YKiuTEh4TNLTKrs8	refresh	3	2025-11-07 08:33:25.27	f
9	2025-10-08 08:38:35.753	2025-10-08 08:38:35.753	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsImlhdCI6MTc1OTkxMjcxNSwiZXhwIjoxNzYyNTA0NzE1LCJ0eXBlIjoicmVmcmVzaCJ9.a5SWd0ghZL0elSzljZFuIXktd6ojO3D9ECz_Bh9Oycs	refresh	3	2025-11-07 08:38:35.753	f
10	2025-10-08 08:38:37.509	2025-10-08 08:38:37.509	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsImlhdCI6MTc1OTkxMjcxNywiZXhwIjoxNzYyNTA0NzE3LCJ0eXBlIjoicmVmcmVzaCJ9.odo0_GV4IiiKRZW92-OfNCiidwFTFIlONYFYNf851iI	refresh	3	2025-11-07 08:38:37.508	f
11	2025-10-08 08:38:37.695	2025-10-08 08:38:37.695	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsImlhdCI6MTc1OTkxMjcxNywiZXhwIjoxNzYyNTA0NzE3LCJ0eXBlIjoicmVmcmVzaCJ9.odo0_GV4IiiKRZW92-OfNCiidwFTFIlONYFYNf851iI	refresh	3	2025-11-07 08:38:37.695	f
12	2025-10-08 08:39:52.384	2025-10-08 08:39:52.384	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTEyNzkyLCJleHAiOjE3NjI1MDQ3OTIsInR5cGUiOiJyZWZyZXNoIn0.1Nficc1lng-AFsrxdS8v0zoFD8N8PMxfDBGze8-R-yg	refresh	3	2025-11-07 08:39:52.376	f
13	2025-10-08 08:41:46.641	2025-10-08 08:41:46.641	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTEyOTA2LCJleHAiOjE3NjI1MDQ5MDYsInR5cGUiOiJyZWZyZXNoIn0.KyaPZ5LiKzP6Lbq9cVq5tDRX-SA0AEkIpAt9IOnRcXQ	refresh	3	2025-11-07 08:41:46.636	f
14	2025-10-08 08:42:15.288	2025-10-08 08:42:15.288	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTEyOTM1LCJleHAiOjE3NjI1MDQ5MzUsInR5cGUiOiJyZWZyZXNoIn0.ZmLGuRCT2oYI_TuN9ucImByGAtaoaqiZ3Qd_klUp5dU	refresh	3	2025-11-07 08:42:15.286	f
15	2025-10-08 08:43:16.138	2025-10-08 08:43:16.138	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTEyOTk2LCJleHAiOjE3NjI1MDQ5OTYsInR5cGUiOiJyZWZyZXNoIn0.RgcWc48FBs8-nXg4YFMcEw8id3yd8xit4ODg2mV59i8	refresh	3	2025-11-07 08:43:16.135	f
16	2025-10-08 08:46:58.706	2025-10-08 08:46:58.706	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTEzMjE4LCJleHAiOjE3NjI1MDUyMTgsInR5cGUiOiJyZWZyZXNoIn0.H3h6e4o09V799VfSnLTW0rnUfLAy8yXGw2zdb0Ix3Do	refresh	3	2025-11-07 08:46:58.701	f
17	2025-10-08 09:20:30.28	2025-10-08 09:20:30.28	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTE1MjMwLCJleHAiOjE3NjI1MDcyMzAsInR5cGUiOiJyZWZyZXNoIn0.Rti0ZnazywsJGxozbpg4GEMwbFLiQTnDN3xxvwmq2ZE	refresh	3	2025-11-07 09:20:30.276	f
18	2025-10-08 09:28:58.248	2025-10-08 09:28:58.248	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTE1NzM4LCJleHAiOjE3NjI1MDc3MzgsInR5cGUiOiJyZWZyZXNoIn0.XAoS-bP9UL5tBTTEFFcPGEJQdHMdKyh1bNJcVNdR_Xc	refresh	3	2025-11-07 09:28:58.243	f
19	2025-10-08 09:30:46.926	2025-10-08 09:30:46.926	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTE1ODQ2LCJleHAiOjE3NjI1MDc4NDYsInR5cGUiOiJyZWZyZXNoIn0.ea1vHC0zq03Bob9RiLFFMsJKRwzMBhkycRWmL1OfDPk	refresh	3	2025-11-07 09:30:46.924	f
20	2025-10-08 11:20:25.73	2025-10-08 11:20:25.73	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTIyNDI1LCJleHAiOjE3NjI1MTQ0MjUsInR5cGUiOiJyZWZyZXNoIn0.Wkblj3betZkLvF2bUEW0EkK6SZnBPwcA1yWXwjpxjak	refresh	3	2025-11-07 11:20:25.725	f
21	2025-10-08 11:29:12.671	2025-10-08 11:29:12.671	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTIyOTUyLCJleHAiOjE3NjI1MTQ5NTIsInR5cGUiOiJyZWZyZXNoIn0.WI-wMFVI3Za9FN6j1pegqJwpn9uem56vMu2D4WJePFw	refresh	3	2025-11-07 11:29:12.669	f
22	2025-10-08 11:37:36.82	2025-10-08 11:37:36.82	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTIzNDU2LCJleHAiOjE3NjI1MTU0NTYsInR5cGUiOiJyZWZyZXNoIn0.YsgIU2Jktr_k2kxr9Oqa-5Olrc-W7VvGpqw_Jlassj0	refresh	3	2025-11-07 11:37:36.814	f
23	2025-10-09 08:35:40.398	2025-10-09 08:35:40.398	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzU5OTk4OTQwLCJleHAiOjE3NjI1OTA5NDAsInR5cGUiOiJyZWZyZXNoIn0.vIB_A64_gE80GRDs0F2jKlCfoEWn40J4c-YBaIVNKgM	refresh	3	2025-11-08 08:35:40.39	f
24	2025-10-09 09:35:03.013	2025-10-09 09:35:03.013	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDAyNTAzLCJleHAiOjE3NjI1OTQ1MDMsInR5cGUiOiJyZWZyZXNoIn0.xYQobmm_giKkkxtysBn3ICLVMK2V8rf-VcIxrcNKXfY	refresh	3	2025-11-08 09:35:03.007	f
75	2025-10-15 07:56:59.154	2025-10-15 07:56:59.154	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwNTE1MDE5LCJleHAiOjE3NjMxMDcwMTksInR5cGUiOiJyZWZyZXNoIn0.ANWVm3ojOaNXP9BZtXhMbDjyfSH2HY7zZyQnBpvGZrE	refresh	3	2025-11-14 07:56:59.155	f
76	2025-10-15 07:57:07.957	2025-10-15 07:57:07.957	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwNTE1MDI3LCJleHAiOjE3NjMxMDcwMjcsInR5cGUiOiJyZWZyZXNoIn0.a2Vw2Lrj76CZlrPLTCIamA2LRFMfB6SlnJ8SDMfhfAE	refresh	3	2025-11-14 07:57:07.959	f
29	2025-10-09 09:59:20.365	2025-10-09 09:59:20.365	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDAzOTYwLCJleHAiOjE3NjI1OTU5NjAsInR5cGUiOiJyZWZyZXNoIn0.ECqc3KqSVcm-LrxpnXVeDUD88ioD-bMG1rRs0W6yJqU	refresh	3	2025-11-08 09:59:20.363	f
30	2025-10-09 10:00:07.588	2025-10-09 10:00:07.588	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDA0MDA3LCJleHAiOjE3NjI1OTYwMDcsInR5cGUiOiJyZWZyZXNoIn0.FEpP9WHSmYnkD-q8qSioRvIuEsvRiETKnmz1gvZskKM	refresh	3	2025-11-08 10:00:07.582	f
31	2025-10-09 10:44:32.865	2025-10-09 10:44:32.865	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDA2NjcyLCJleHAiOjE3NjI1OTg2NzIsInR5cGUiOiJyZWZyZXNoIn0.s7og6aZvM1QvGqNPyZSj5T9F4G63D882iiLDTvRPpD8	refresh	3	2025-11-08 10:44:32.861	f
32	2025-10-09 10:50:32.563	2025-10-09 10:50:32.563	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDA3MDMyLCJleHAiOjE3NjI1OTkwMzIsInR5cGUiOiJyZWZyZXNoIn0.8vnO0EjRplce5uUONDqhY-KVZEXZTypnru6iHeQtwLQ	refresh	3	2025-11-08 10:50:32.557	f
33	2025-10-09 10:54:07.874	2025-10-09 10:54:07.874	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDA3MjQ3LCJleHAiOjE3NjI1OTkyNDcsInR5cGUiOiJyZWZyZXNoIn0.A_9apbd1eivEsx9EOGR8OKDPYgW0fTSWvayQeHHuJaE	refresh	3	2025-11-08 10:54:07.869	f
34	2025-10-09 10:59:02.394	2025-10-09 10:59:02.394	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDA3NTQyLCJleHAiOjE3NjI1OTk1NDIsInR5cGUiOiJyZWZyZXNoIn0.90g5suWeXqAWFrWuMPyiUIZzW_8soMMEchZQf3nZnuo	refresh	3	2025-11-08 10:59:02.39	f
35	2025-10-09 12:23:57.707	2025-10-09 12:23:57.707	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDEyNjM3LCJleHAiOjE3NjI2MDQ2MzcsInR5cGUiOiJyZWZyZXNoIn0.IIEudJYthTZfSpBnKOTRPSpX8nnGf0wFA_JBqRuOiA4	refresh	3	2025-11-08 12:23:57.702	f
36	2025-10-09 13:29:40.717	2025-10-09 13:29:40.717	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDE2NTgwLCJleHAiOjE3NjI2MDg1ODAsInR5cGUiOiJyZWZyZXNoIn0.JkDJDxvFrct5kXzo14j68_YYJN5HG_N2dqU5e-dDDd0	refresh	3	2025-11-08 13:29:40.709	f
37	2025-10-09 13:35:35.371	2025-10-09 13:35:35.371	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDE2OTM1LCJleHAiOjE3NjI2MDg5MzUsInR5cGUiOiJyZWZyZXNoIn0.aPJzoJudAW8CL0N-kyJ02Q4-fqWLTaBczb6yUcm637Y	refresh	3	2025-11-08 13:35:35.366	f
38	2025-10-09 13:36:53.514	2025-10-09 13:36:53.514	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDE3MDEzLCJleHAiOjE3NjI2MDkwMTMsInR5cGUiOiJyZWZyZXNoIn0.WzNyKoJirOixoZf1IDBgD_55oNjbSmKPEsWC4WZNduQ	refresh	3	2025-11-08 13:36:53.511	f
39	2025-10-10 07:12:12.466	2025-10-10 07:12:12.466	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDgwMzMyLCJleHAiOjE3NjI2NzIzMzIsInR5cGUiOiJyZWZyZXNoIn0.nqUJcfnc0Ml-tqabRuOROwuUQ9APUB-et44Ue0iCbgw	refresh	3	2025-11-09 07:12:12.462	f
40	2025-10-10 08:27:16.273	2025-10-10 08:27:16.273	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDg0ODM2LCJleHAiOjE3NjI2NzY4MzYsInR5cGUiOiJyZWZyZXNoIn0.Z6mInZmsux46t_2LDOk6eCJMdZUJ8A2MraoLYoB1eJE	refresh	3	2025-11-09 08:27:16.268	f
41	2025-10-10 08:30:50.482	2025-10-10 08:30:50.482	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDg1MDUwLCJleHAiOjE3NjI2NzcwNTAsInR5cGUiOiJyZWZyZXNoIn0.RfVHE3JynW2L-E6GOsjlNaiLg8ce8iPKTM_Y7NkBrpY	refresh	3	2025-11-09 08:30:50.481	f
42	2025-10-10 08:42:34.516	2025-10-10 08:42:34.516	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDg1NzU0LCJleHAiOjE3NjI2Nzc3NTQsInR5cGUiOiJyZWZyZXNoIn0.ENttsgQ6v_6H8doPZ5kbUrXq-n_6YiTe6Vhnyq5Wn4A	refresh	3	2025-11-09 08:42:34.512	f
43	2025-10-10 08:43:03.915	2025-10-10 08:43:03.915	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjQsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDg1NzgzLCJleHAiOjE3NjI2Nzc3ODMsInR5cGUiOiJyZWZyZXNoIn0.wX0Rc2P6f8xfG-hJDlUwYPCTCRN_CAluuVcgyY27zeY	refresh	4	2025-11-09 08:43:03.913	f
44	2025-10-10 08:43:19.581	2025-10-10 08:43:19.581	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDg1Nzk5LCJleHAiOjE3NjI2Nzc3OTksInR5cGUiOiJyZWZyZXNoIn0.rkBqehQr6A_UUnBJGdJ4ag5SSU0A2LFOoe2Re8nTC2c	refresh	3	2025-11-09 08:43:19.579	f
45	2025-10-10 08:43:34.191	2025-10-10 08:43:34.191	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjQsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDg1ODE0LCJleHAiOjE3NjI2Nzc4MTQsInR5cGUiOiJyZWZyZXNoIn0.LOJRNbrYBw6CTQe5IuO3-jPyS9BbVSKRxrTfgpiM5Os	refresh	4	2025-11-09 08:43:34.19	f
46	2025-10-10 09:07:14.022	2025-10-10 09:07:14.022	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDg3MjM0LCJleHAiOjE3NjI2NzkyMzQsInR5cGUiOiJyZWZyZXNoIn0.jyd9TEAkymCP8rEN6ymIBNX2K37krj01D7P47MF5J7I	refresh	3	2025-11-09 09:07:14.019	f
47	2025-10-10 11:25:05.188	2025-10-10 11:25:05.188	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjQsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDk1NTA1LCJleHAiOjE3NjI2ODc1MDUsInR5cGUiOiJyZWZyZXNoIn0.75BHr7bSYJVcVlen9Y6nntA0K_AcmBzeOiRQK7m1cH8	refresh	4	2025-11-09 11:25:05.182	f
48	2025-10-10 11:29:17.253	2025-10-10 11:29:17.253	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjQsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDk1NzU3LCJleHAiOjE3NjI2ODc3NTcsInR5cGUiOiJyZWZyZXNoIn0.5EtBbm69vFnT0WUuo5cJz69-NlDT1MQRZRxjZ2ANWnE	refresh	4	2025-11-09 11:29:17.248	f
49	2025-10-10 11:32:34.78	2025-10-10 11:32:34.78	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjQsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDk1OTU0LCJleHAiOjE3NjI2ODc5NTQsInR5cGUiOiJyZWZyZXNoIn0.UhETGpi5T8-piiexCWpcdZRPDhADkMfxHAUHZvaYcBM	refresh	4	2025-11-09 11:32:34.777	f
50	2025-10-10 11:35:09.578	2025-10-10 11:35:09.578	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjQsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDk2MTA5LCJleHAiOjE3NjI2ODgxMDksInR5cGUiOiJyZWZyZXNoIn0.2DSJtksoVIle1WvcxSwQezupFtMXQQD3yhe42hoGgNE	refresh	4	2025-11-09 11:35:09.572	f
51	2025-10-10 11:39:35.718	2025-10-10 11:39:35.718	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjQsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMDk2Mzc1LCJleHAiOjE3NjI2ODgzNzUsInR5cGUiOiJyZWZyZXNoIn0.XH8Podd2sWX3Gkf5kCOVVLaTPSC6DUt23dP3vo9EEZY	refresh	4	2025-11-09 11:39:35.713	f
52	2025-10-10 12:47:47.008	2025-10-10 12:47:47.008	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMTAwNDY3LCJleHAiOjE3NjI2OTI0NjcsInR5cGUiOiJyZWZyZXNoIn0.eIFZFNt1JgbkahS7kxRR2tSLOsPzRbvT9AWGTsuVOGI	refresh	3	2025-11-09 12:47:47.003	f
53	2025-10-10 12:54:51.281	2025-10-10 12:54:51.281	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMTAwODkxLCJleHAiOjE3NjI2OTI4OTEsInR5cGUiOiJyZWZyZXNoIn0.tWDBVtguQ20SOmiohY9cSLAYgh46uKxejsqmw3xhfsw	refresh	3	2025-11-09 12:54:51.277	f
54	2025-10-10 12:57:52.012	2025-10-10 12:57:52.012	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMTAxMDcyLCJleHAiOjE3NjI2OTMwNzIsInR5cGUiOiJyZWZyZXNoIn0.InSmUNeAmbJSbSLjcTPpY4BtB8fwCNPTIPnfNeeuQ3c	refresh	3	2025-11-09 12:57:52.009	f
55	2025-10-10 13:37:37.108	2025-10-10 13:37:37.108	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjQsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMTAzNDU3LCJleHAiOjE3NjI2OTU0NTcsInR5cGUiOiJyZWZyZXNoIn0.kt3lj4SdESIvKQav2BP2EqnVZxWmrogSBTZ5PYuNiIo	refresh	4	2025-11-09 13:37:37.102	f
56	2025-10-10 21:48:03.551	2025-10-10 21:48:03.551	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMTMyODgzLCJleHAiOjE3NjI3MjQ4ODMsInR5cGUiOiJyZWZyZXNoIn0.06l-2cqIB8vUkedR_J3KoKxzK45Pj8DLIaISV5r2w04	refresh	3	2025-11-09 21:48:03.551	f
57	2025-10-10 22:02:58.525	2025-10-10 22:02:58.525	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMTMzNzc4LCJleHAiOjE3NjI3MjU3NzgsInR5cGUiOiJyZWZyZXNoIn0.qdlKOhF_2wTgYFYGbM6E7aTvWcx429Gi4mJOOGN4OZY	refresh	3	2025-11-09 22:02:58.523	f
58	2025-10-10 22:12:44.45	2025-10-10 22:12:44.45	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMTM0MzY0LCJleHAiOjE3NjI3MjYzNjQsInR5cGUiOiJyZWZyZXNoIn0.rYFoz22QaiAnWa26F2J5Hg6LV5-8q9aDD9grxyj0RSI	refresh	3	2025-11-09 22:12:44.45	f
59	2025-10-10 22:14:56.724	2025-10-10 22:14:56.724	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMTM0NDk2LCJleHAiOjE3NjI3MjY0OTYsInR5cGUiOiJyZWZyZXNoIn0.ctcfrqXJtA9GgWJgEpj8rh1-16rT9fWgqHT6TBAV_cc	refresh	3	2025-11-09 22:14:56.721	f
60	2025-10-10 22:18:10.354	2025-10-10 22:18:10.354	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMTM0NjkwLCJleHAiOjE3NjI3MjY2OTAsInR5cGUiOiJyZWZyZXNoIn0.jGzMJx6WmMHMArp-y9VkH7nC3Lp_OyPcQD716Q5ZAsA	refresh	3	2025-11-09 22:18:10.35	f
61	2025-10-10 22:22:31.568	2025-10-10 22:22:31.568	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjQsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMTM0OTUxLCJleHAiOjE3NjI3MjY5NTEsInR5cGUiOiJyZWZyZXNoIn0.ZScU6z6ElJF3KmRkmmSkiPkaGaq07K99IVYrTMatYpM	refresh	4	2025-11-09 22:22:31.565	f
62	2025-10-10 22:22:59.376	2025-10-10 22:22:59.376	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMTM0OTc5LCJleHAiOjE3NjI3MjY5NzksInR5cGUiOiJyZWZyZXNoIn0.ql17cf_ZrFVwYC38ex0fJ46Xx71S1WfZEUHErQNoIg8	refresh	3	2025-11-09 22:22:59.375	f
63	2025-10-10 22:24:09.147	2025-10-10 22:24:09.147	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMTM1MDQ5LCJleHAiOjE3NjI3MjcwNDksInR5cGUiOiJyZWZyZXNoIn0.PD3zj_Ivw1aIlDInQbHDcBQQwaw04-bY041SQlmbDyo	refresh	3	2025-11-09 22:24:09.141	f
64	2025-10-10 22:24:37.052	2025-10-10 22:24:37.052	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjQsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMTM1MDc3LCJleHAiOjE3NjI3MjcwNzcsInR5cGUiOiJyZWZyZXNoIn0.dA8AsQ9divre9cPk44BLINneaNDDorONJKDEIC5SCGE	refresh	4	2025-11-09 22:24:37.052	f
65	2025-10-11 09:22:28.078	2025-10-11 09:22:28.078	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwMTc0NTQ4LCJleHAiOjE3NjI3NjY1NDgsInR5cGUiOiJyZWZyZXNoIn0.gMueJjkF5hNijL5A-f16kOZHJXmgOAYISpWR3B413Ww	refresh	3	2025-11-10 09:22:28.073	f
66	2025-10-14 08:03:20.604	2025-10-14 08:03:20.604	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwNDI5MDAwLCJleHAiOjE3NjMwMjEwMDAsInR5cGUiOiJyZWZyZXNoIn0.Xud1t2ydLpV5uOL8MbbrNPJSQ_KTwDUrT-NZ4lYG5c4	refresh	3	2025-11-13 08:03:20.599	f
67	2025-10-14 08:45:48.886	2025-10-14 08:45:48.886	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwNDMxNTQ4LCJleHAiOjE3NjMwMjM1NDgsInR5cGUiOiJyZWZyZXNoIn0.GK9opbNmId65q2aY6YUsv_cu1g4TO3JjkvbcwQdOudA	refresh	3	2025-11-13 08:45:48.882	f
68	2025-10-14 09:25:35.132	2025-10-14 09:25:35.132	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwNDMzOTM1LCJleHAiOjE3NjMwMjU5MzUsInR5cGUiOiJyZWZyZXNoIn0.wBFr9zeUcgrITPobvlGkXHxYeBr8ZC6GC4aBX3gBG8s	refresh	3	2025-11-13 09:25:35.127	f
69	2025-10-14 10:45:59.4	2025-10-14 10:45:59.4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwNDM4NzU5LCJleHAiOjE3NjMwMzA3NTksInR5cGUiOiJyZWZyZXNoIn0.uEyrKaB4HTYmvjsur1XS7yV1kYLeg8uhEAiiq1s606o	refresh	3	2025-11-13 10:45:59.396	f
70	2025-10-14 12:28:10.3	2025-10-14 12:28:10.3	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwNDQ0ODkwLCJleHAiOjE3NjMwMzY4OTAsInR5cGUiOiJyZWZyZXNoIn0.TbwpKERws9cSyPRTEMDpMIDyAwogNf6ftbYQ5T5_RVs	refresh	3	2025-11-13 12:28:10.295	f
71	2025-10-14 12:40:33.415	2025-10-14 12:40:33.415	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwNDQ1NjMzLCJleHAiOjE3NjMwMzc2MzMsInR5cGUiOiJyZWZyZXNoIn0.UHjfjyZLtnTre4HI_jxdqFsdaKyUOTIvBvt3Ttj2xiQ	refresh	3	2025-11-13 12:40:33.411	f
72	2025-10-14 13:32:00.674	2025-10-14 13:32:00.674	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwNDQ4NzIwLCJleHAiOjE3NjMwNDA3MjAsInR5cGUiOiJyZWZyZXNoIn0.CCrVmtyWdp3SaBxdrqHUWZ5TUEjIAlzZYoDnllwEOak	refresh	3	2025-11-13 13:32:00.669	f
73	2025-10-14 14:03:17.469	2025-10-14 14:03:17.469	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwNDUwNTk3LCJleHAiOjE3NjMwNDI1OTcsInR5cGUiOiJyZWZyZXNoIn0.u1vlUBG0NCwgHDdVgzW-7P5BQOoXr6EVSF-yThrgkUM	refresh	3	2025-11-13 14:03:17.464	f
74	2025-10-15 07:27:54.135	2025-10-15 07:27:54.135	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsInJvbGUiOiJ1c2VyIiwiaWF0IjoxNzYwNTEzMjc0LCJleHAiOjE3NjMxMDUyNzQsInR5cGUiOiJyZWZyZXNoIn0.GxO0Sc6i-oqYNuR842MjYdUbJVf3QvLJUyBdEuIsP4w	refresh	3	2025-11-14 07:27:54.138	f
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, "createdAt", "updatedAt", "deletedAt", status, name, email, password, role, "isEmailVerified") FROM stdin;
2	2025-10-08 08:18:38.577	2025-10-08 08:18:38.577	\N	t	Admin User	admin@test.com	$2a$08$cMcEgMv9zNuxcH5HKtkm/OnfK6SzFp0PVNq9GCc.Nzwj/T.cXm4v6	user	f
3	2025-10-08 08:28:39.213	2025-10-08 08:28:39.213	\N	t	Test User	test@test.com	$2a$08$CGP25qTrLehLLH8TNRGUdexOxaYG3h8yd4kR58mhA9teVh8dG.DIq	user	f
4	2025-10-10 08:43:03.909	2025-10-10 08:43:03.909	\N	t	yusuf	yusufguclu99@hotmail.com	$2a$08$kHXR/TSy/sfdFk1FQLHXX..yP7Ww6OhIrFeIV0nfGilgRp3nZDyZq	user	f
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
10cca9e0-159e-4e7d-b48f-1f0a723563cf	a144f3bdf027e922a17559e95b1258cc5df19dd0301a05f29a78e9764be41adc	2025-10-07 17:21:01.37436+03	20251007142101_init	\N	\N	2025-10-07 17:21:01.343792+03	1
9b37a9c8-e69d-4bdf-80fd-60bf92159b20	62eb0be2ab7ccb42c8ed21609d79bb3a9ee7adb197d2ec39c8988a521bcadefc	2025-10-08 10:19:05.970127+03	20251008071905_add_backup_models	\N	\N	2025-10-08 10:19:05.938449+03	1
fc6ea248-e5a9-4343-89c1-db880ae4772f	0ac2eec65854a607c01fb7d5cc6d9e157828d1eb4a82de2af33aabc7a4422fda	\N	20251008232716_add_token_unique_constraint	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20251008232716_add_token_unique_constraint\n\nDatabase error code: 23505\n\nDatabase error:\nERROR: could not create unique index "Token_token_key"\nDETAIL: Key (token)=(eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsImlhdCI6MTc1OTkxMjcxNywiZXhwIjoxNzYyNTA0NzE3LCJ0eXBlIjoicmVmcmVzaCJ9.odo0_GV4IiiKRZW92-OfNCiidwFTFIlONYFYNf851iI) is duplicated.\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E23505), message: "could not create unique index \\"Token_token_key\\"", detail: Some("Key (token)=(eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOjMsImlhdCI6MTc1OTkxMjcxNywiZXhwIjoxNzYyNTA0NzE3LCJ0eXBlIjoicmVmcmVzaCJ9.odo0_GV4IiiKRZW92-OfNCiidwFTFIlONYFYNf851iI) is duplicated."), hint: None, position: None, where_: None, schema: Some("public"), table: Some("Token"), column: None, datatype: None, constraint: Some("Token_token_key"), file: Some("tuplesort.c"), line: Some(4304), routine: Some("comparetup_index_btree") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20251008232716_add_token_unique_constraint"\n             at schema-engine\\connectors\\sql-schema-connector\\src\\apply_migration.rs:106\n   1: schema_core::commands::apply_migrations::Applying migration\n           with migration_name="20251008232716_add_token_unique_constraint"\n             at schema-engine\\core\\src\\commands\\apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine\\core\\src\\state.rs:197	2025-10-09 11:31:18.106237+03	2025-10-09 11:30:49.438234+03	0
576d66ae-c21f-4714-968a-3101e29d5627	0ac2eec65854a607c01fb7d5cc6d9e157828d1eb4a82de2af33aabc7a4422fda	2025-10-09 11:31:18.116355+03	20251008232716_add_token_unique_constraint		\N	2025-10-09 11:31:18.116355+03	0
\.


--
-- Name: BackupHistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."BackupHistory_id_seq"', 22, true);


--
-- Name: BackupJob_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."BackupJob_id_seq"', 6, true);


--
-- Name: CloudStorage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CloudStorage_id_seq"', 2, true);


--
-- Name: Database_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Database_id_seq"', 2, true);


--
-- Name: NotificationSettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."NotificationSettings_id_seq"', 2, true);


--
-- Name: Token_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Token_id_seq"', 76, true);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."User_id_seq"', 4, true);


--
-- Name: BackupHistory BackupHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BackupHistory"
    ADD CONSTRAINT "BackupHistory_pkey" PRIMARY KEY (id);


--
-- Name: BackupJob BackupJob_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BackupJob"
    ADD CONSTRAINT "BackupJob_pkey" PRIMARY KEY (id);


--
-- Name: CloudStorage CloudStorage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CloudStorage"
    ADD CONSTRAINT "CloudStorage_pkey" PRIMARY KEY (id);


--
-- Name: Database Database_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Database"
    ADD CONSTRAINT "Database_pkey" PRIMARY KEY (id);


--
-- Name: NotificationSettings NotificationSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NotificationSettings"
    ADD CONSTRAINT "NotificationSettings_pkey" PRIMARY KEY (id);


--
-- Name: Token Token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Token"
    ADD CONSTRAINT "Token_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: NotificationSettings_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "NotificationSettings_userId_key" ON public."NotificationSettings" USING btree ("userId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: BackupHistory BackupHistory_backupJobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BackupHistory"
    ADD CONSTRAINT "BackupHistory_backupJobId_fkey" FOREIGN KEY ("backupJobId") REFERENCES public."BackupJob"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: BackupHistory BackupHistory_databaseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BackupHistory"
    ADD CONSTRAINT "BackupHistory_databaseId_fkey" FOREIGN KEY ("databaseId") REFERENCES public."Database"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BackupJob BackupJob_cloudStorageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BackupJob"
    ADD CONSTRAINT "BackupJob_cloudStorageId_fkey" FOREIGN KEY ("cloudStorageId") REFERENCES public."CloudStorage"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: BackupJob BackupJob_databaseId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BackupJob"
    ADD CONSTRAINT "BackupJob_databaseId_fkey" FOREIGN KEY ("databaseId") REFERENCES public."Database"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CloudStorage CloudStorage_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CloudStorage"
    ADD CONSTRAINT "CloudStorage_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Database Database_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Database"
    ADD CONSTRAINT "Database_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: NotificationSettings NotificationSettings_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."NotificationSettings"
    ADD CONSTRAINT "NotificationSettings_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Token Token_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Token"
    ADD CONSTRAINT "Token_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict cSXh6fVsIS8fMh66S6bL3RZE9FefqKtRTxvEsLieDuztjZAIguSZRvuYyfbqg10

