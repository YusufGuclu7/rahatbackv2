--
-- Database creation with UTF8 encoding (safe for all platforms)
--

CREATE DATABASE s3test WITH ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C' TEMPLATE = template0;

ALTER DATABASE s3test OWNER TO postgres;

\connect s3test

--
-- PostgreSQL database dump
--

\restrict sV8gqAvAMlOblFbaOejFXGJk7FDG5dwDHwhi6c7SnjBGOoLhveT5yirxJUvjxS2

-- Dumped from database version 14.19
-- Dumped by pg_dump version 14.19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict sV8gqAvAMlOblFbaOejFXGJk7FDG5dwDHwhi6c7SnjBGOoLhveT5yirxJUvjxS2

