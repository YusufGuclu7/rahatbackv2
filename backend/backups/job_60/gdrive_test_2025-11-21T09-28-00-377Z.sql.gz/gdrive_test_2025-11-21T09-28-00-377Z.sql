--
-- Database creation with UTF8 encoding (safe for all platforms)
--

CREATE DATABASE gdrive_test WITH ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C' TEMPLATE = template0;

ALTER DATABASE gdrive_test OWNER TO postgres;

\connect gdrive_test

--
-- PostgreSQL database dump
--

\restrict lgRPIYQpRc5JP9TKcmqJIScmB3NMlbifRi7AAdjEhpXTGgyFHWcZ9gvUc8ZaYXQ

-- Dumped from database version 14.19
-- Dumped by pg_dump version 14.19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ogrenciler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ogrenciler (
    id integer NOT NULL,
    ad character varying(50) NOT NULL,
    soyad character varying(50) NOT NULL,
    yas integer,
    email character varying(100),
    kayit_tarihi date
);


ALTER TABLE public.ogrenciler OWNER TO postgres;

--
-- Name: ogrenciler_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ogrenciler_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ogrenciler_id_seq OWNER TO postgres;

--
-- Name: ogrenciler_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ogrenciler_id_seq OWNED BY public.ogrenciler.id;


--
-- Name: ogrenciler id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ogrenciler ALTER COLUMN id SET DEFAULT nextval('public.ogrenciler_id_seq'::regclass);


--
-- Data for Name: ogrenciler; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ogrenciler (id, ad, soyad, yas, email, kayit_tarihi) FROM stdin;
1	Ahmet	Yılmaz	20	ahmet@email.com	2024-01-15
2	Ayşe	Demir	22	ayse@email.com	2024-02-10
3	Mehmet	Kaya	21	mehmet@email.com	2024-03-05
4	Fatma	Arslan	24	fatma@email.com	2024-04-12
5	Ali	Çelik	19	ali@email.com	2024-05-08
6	Elif	Kurt	23	elif@email.com	2024-06-15
7	Burak	Yıldız	20	burak@email.com	2024-07-20
8	Selin	Aydın	22	selin@email.com	2024-08-03
9	Emre	Özdemir	21	emre@email.com	2024-09-11
10	Merve	Koç	25	merve@email.com	2024-10-05
11	Cem	Şen	18	cem@email.com	2024-11-14
\.


--
-- Name: ogrenciler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ogrenciler_id_seq', 11, true);


--
-- Name: ogrenciler ogrenciler_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ogrenciler
    ADD CONSTRAINT ogrenciler_email_key UNIQUE (email);


--
-- Name: ogrenciler ogrenciler_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ogrenciler
    ADD CONSTRAINT ogrenciler_pkey PRIMARY KEY (id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict lgRPIYQpRc5JP9TKcmqJIScmB3NMlbifRi7AAdjEhpXTGgyFHWcZ9gvUc8ZaYXQ

